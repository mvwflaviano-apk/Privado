# App de Inventário (Android)

Projeto Android em Kotlin + Jetpack Compose + Room, feito a partir da especificação
"App Android de Inventário".

## O que o app faz
- **Inventários (sessões)** separados: criar, abrir, renomear, excluir e consultar contagens anteriores.
- **Contagem**: campo de código sempre pronto para o coletor (modo teclado/wedge, Enter ou Tab no fim).
  - Código já contado na sessão → soma 1, sem duplicar linha.
  - Código na lista de produtos → cria o item com a descrição preenchida.
  - Código desconhecido → aviso "Produto não localizado" com opções: cadastrar descrição,
    vincular a um produto existente (corrigir vínculo), contar sem descrição ou ignorar.
  - Botões − / + em cada linha; toque no item para editar descrição e quantidade.
- **Produtos**: cadastro manual, busca, edição, e importação de **.xls, .xlsm, .xlsx e .csv**
  escolhendo a aba e quais colunas são o código de barras e a descrição.
- **Exportação** em CSV (abre no Excel, com acentos e código de barras protegido),
  por compartilhamento (WhatsApp, e-mail, Drive) ou salvando no aparelho. Data e hora da
  exportação ficam registradas na sessão.
- Tudo salvo no aparelho (Room/SQLite) — nada se perde ao fechar o app.
- **Leitura por Intent** (opcional, em Configurações) para coletores Zebra, Honeywell, Urovo,
  Chainway, Newland etc.

## Como gerar o APK

### Opção A — GitHub (sem instalar nada no PC)
1. Crie uma conta grátis em github.com e um repositório novo (pode ser privado).
2. Clique em "uploading an existing file" e arraste **todo o conteúdo** desta pasta
   (inclusive a pasta `.github`). Confirme com "Commit changes".
3. Abra a aba **Actions**: o fluxo "Gerar APK" roda sozinho (~5 min).
4. Ao terminar (ícone verde), abra a execução e baixe **Inventario-APK** em "Artifacts".
   Dentro do .zip está o `Inventario.apk`.

### Opção B — Android Studio
1. Instale o Android Studio (developer.android.com/studio).
2. File → Open → selecione esta pasta. Aguarde a sincronização.
3. Build → Build App Bundle(s) / APK(s) → Build APK(s).
4. O APK fica em `app/build/outputs/apk/`.

## Instalar no coletor
Copie o `.apk` para o aparelho e abra. Se pedir, permita "instalar apps de fontes desconhecidas".

## Configurar leitura por Intent (opcional)
Em Configurações do app, toque em "Usar ação sugerida" (`br.com.flaviano.inventario.SCAN`).
No app de configuração do leitor do coletor, ative a saída por **Intent/Broadcast** com essa ação.
Se o seu modelo usar um nome de extra diferente dos comuns, informe-o no campo "Nome do extra".
