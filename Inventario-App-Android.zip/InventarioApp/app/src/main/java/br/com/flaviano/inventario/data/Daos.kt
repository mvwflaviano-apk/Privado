package br.com.flaviano.inventario.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SessaoDao {
    @Query(
        """
        SELECT s.id, s.nome, s.criadaEm, s.exportadaEm,
               COUNT(i.id) AS totalItens, SUM(i.quantidade) AS totalQuantidade
        FROM sessoes s LEFT JOIN itens i ON i.sessaoId = s.id
        GROUP BY s.id ORDER BY s.criadaEm DESC
        """
    )
    fun observarResumos(): Flow<List<SessaoResumo>>

    @Query("SELECT * FROM sessoes WHERE id = :id")
    fun observar(id: Long): Flow<SessaoInventario?>

    @Query("SELECT * FROM sessoes WHERE id = :id")
    suspend fun obter(id: Long): SessaoInventario?

    @Insert
    suspend fun inserir(sessao: SessaoInventario): Long

    @Update
    suspend fun atualizar(sessao: SessaoInventario)

    @Query("UPDATE sessoes SET exportadaEm = :quando WHERE id = :id")
    suspend fun marcarExportada(id: Long, quando: Long)

    @Delete
    suspend fun excluir(sessao: SessaoInventario)
}

@Dao
interface ItemDao {
    @Query("SELECT * FROM itens WHERE sessaoId = :sessaoId ORDER BY atualizadoEm DESC, id DESC")
    fun observarDaSessao(sessaoId: Long): Flow<List<ItemContado>>

    @Query("SELECT * FROM itens WHERE sessaoId = :sessaoId ORDER BY id ASC")
    suspend fun listarDaSessao(sessaoId: Long): List<ItemContado>

    @Query("SELECT * FROM itens WHERE sessaoId = :sessaoId AND codigoBarras = :codigo LIMIT 1")
    suspend fun buscar(sessaoId: Long, codigo: String): ItemContado?

    @Query("SELECT * FROM itens WHERE id = :id")
    suspend fun obter(id: Long): ItemContado?

    @Insert
    suspend fun inserir(item: ItemContado): Long

    @Update
    suspend fun atualizar(item: ItemContado)

    @Delete
    suspend fun excluir(item: ItemContado)
}

@Dao
abstract class ProdutoDao {
    @Query(
        """
        SELECT * FROM produtos
        WHERE :filtro = '' OR produto LIKE '%' || :filtro || '%' OR codigoBarras LIKE '%' || :filtro || '%'
        ORDER BY produto COLLATE NOCASE LIMIT 500
        """
    )
    abstract fun observar(filtro: String): Flow<List<ProdutoCadastrado>>

    @Query("SELECT COUNT(*) FROM produtos")
    abstract fun observarTotal(): Flow<Int>

    @Query("SELECT * FROM produtos WHERE codigoBarras = :codigo LIMIT 1")
    abstract suspend fun porCodigo(codigo: String): ProdutoCadastrado?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun salvar(produto: ProdutoCadastrado): Long

    @Update
    abstract suspend fun atualizar(produto: ProdutoCadastrado)

    @Delete
    abstract suspend fun excluir(produto: ProdutoCadastrado)

    @Query("DELETE FROM produtos")
    abstract suspend fun excluirTodos()

    /** Insere ou atualiza pela chave código de barras, preservando o id existente. */
    @Transaction
    open suspend fun importar(lista: List<Pair<String, String>>, substituirTudo: Boolean): Int {
        if (substituirTudo) excluirTodos()
        var n = 0
        for ((codigo, descricao) in lista) {
            val existente = porCodigo(codigo)
            if (existente != null) {
                atualizar(existente.copy(produto = descricao))
            } else {
                salvar(ProdutoCadastrado(produto = descricao, codigoBarras = codigo))
            }
            n++
        }
        return n
    }
}
