package br.com.flaviano.inventario.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [SessaoInventario::class, ItemContado::class, ProdutoCadastrado::class],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun sessaoDao(): SessaoDao
    abstract fun itemDao(): ItemDao
    abstract fun produtoDao(): ProdutoDao

    companion object {
        @Volatile private var instancia: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "inventario.db",
                ).build().also { instancia = it }
            }
    }
}
