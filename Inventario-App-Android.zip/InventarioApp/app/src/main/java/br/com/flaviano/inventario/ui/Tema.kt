package br.com.flaviano.inventario.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Azul = Color(0xFF1F4E79)
val AzulClaro = Color(0xFFD6E4F0)
val Verde = Color(0xFF2E7D32)
val VerdeClaro = Color(0xFFE3F2E5)
val Vermelho = Color(0xFFC62828)
val VermelhoClaro = Color(0xFFFDE7E7)

private val cores = lightColorScheme(
    primary = Azul,
    onPrimary = Color.White,
    primaryContainer = AzulClaro,
    onPrimaryContainer = Color(0xFF0B2540),
    secondary = Color(0xFFF2B134),
    onSecondary = Color(0xFF2B1D00),
    error = Vermelho,
)

@Composable
fun InventarioTema(conteudo: @Composable () -> Unit) {
    MaterialTheme(colorScheme = cores, content = conteudo)
}
