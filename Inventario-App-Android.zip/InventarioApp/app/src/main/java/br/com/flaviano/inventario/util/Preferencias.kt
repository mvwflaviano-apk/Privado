package br.com.flaviano.inventario.util

import android.content.Context

/** Configurações simples guardadas no aparelho. */
class Preferencias(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("config", Context.MODE_PRIVATE)

    /** Ação do broadcast enviado pelo coletor (modo Intent). Vazio = desativado. */
    var intentAcao: String
        get() = sp.getString("intentAcao", "") ?: ""
        set(v) = sp.edit().putString("intentAcao", v.trim()).apply()

    /** Nome do extra que contém o código. Vazio = tentar os nomes mais comuns. */
    var intentExtra: String
        get() = sp.getString("intentExtra", "") ?: ""
        set(v) = sp.edit().putString("intentExtra", v.trim()).apply()

    var esconderTeclado: Boolean
        get() = sp.getBoolean("esconderTeclado", true)
        set(v) = sp.edit().putBoolean("esconderTeclado", v).apply()

    var som: Boolean
        get() = sp.getBoolean("som", true)
        set(v) = sp.edit().putBoolean("som", v).apply()

    var vibrar: Boolean
        get() = sp.getBoolean("vibrar", true)
        set(v) = sp.edit().putBoolean("vibrar", v).apply()

    /** Grava o código como ="789..." para o Excel não transformar em número científico. */
    var protegerCodigoExcel: Boolean
        get() = sp.getBoolean("protegerCodigoExcel", true)
        set(v) = sp.edit().putBoolean("protegerCodigoExcel", v).apply()

    /** Separador do CSV: ";" (Excel em português) ou ",". */
    var separadorCsv: String
        get() = sp.getString("separadorCsv", ";") ?: ";"
        set(v) = sp.edit().putString("separadorCsv", v).apply()
}
