package br.com.flaviano.inventario.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Xml
import jxl.CellType
import jxl.NumberCell
import jxl.Workbook
import jxl.WorkbookSettings
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.math.BigDecimal
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

/** Uma aba da planilha: linhas x colunas, tudo como texto. */
data class Planilha(val nome: String, val linhas: List<List<String>>) {
    val totalColunas: Int get() = linhas.maxOfOrNull { it.size } ?: 0
}

/**
 * Lê .csv, .xls (Excel 97-2003) e .xlsx/.xlsm (Excel 2007+, inclusive com macros).
 */
object LeitorPlanilha {

    fun nomeDoArquivo(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) return c.getString(0) ?: "" }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    fun ler(context: Context, uri: Uri): List<Planilha> {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalArgumentException("Não foi possível abrir o arquivo.")
        val nome = nomeDoArquivo(context, uri).lowercase()
        return when {
            ehZip(bytes) -> lerXlsx(bytes)
            ehOle(bytes) -> lerXls(bytes)
            nome.endsWith(".xlsx") || nome.endsWith(".xlsm") ->
                throw IllegalArgumentException("Arquivo Excel inválido ou corrompido.")
            nome.endsWith(".xls") ->
                throw IllegalArgumentException("Arquivo .xls inválido ou corrompido.")
            else -> listOf(Planilha("CSV", lerCsv(bytes)))
        }
    }

    private fun ehZip(b: ByteArray) = b.size > 4 && b[0] == 0x50.toByte() && b[1] == 0x4B.toByte()
    private fun ehOle(b: ByteArray) = b.size > 8 &&
        b[0] == 0xD0.toByte() && b[1] == 0xCF.toByte() && b[2] == 0x11.toByte() && b[3] == 0xE0.toByte()

    // ---------------- CSV ----------------

    private fun decodificar(bytes: ByteArray): String {
        // BOM UTF-8
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: CharacterCodingException) {
            // Excel brasileiro costuma salvar CSV em Windows-1252
            String(bytes, Charset.forName("windows-1252"))
        }
    }

    fun lerCsv(bytes: ByteArray): List<List<String>> {
        val texto = decodificar(bytes)
        val primeiraLinha = texto.lineSequence().firstOrNull { it.isNotBlank() } ?: return emptyList()
        val sep = listOf(';', ',', '\t', '|').maxByOrNull { c -> primeiraLinha.count { it == c } } ?: ';'

        val linhas = ArrayList<List<String>>()
        var campos = ArrayList<String>()
        val campo = StringBuilder()
        var aspas = false
        var i = 0
        while (i < texto.length) {
            val ch = texto[i]
            if (aspas) {
                if (ch == '"') {
                    if (i + 1 < texto.length && texto[i + 1] == '"') { campo.append('"'); i++ } else aspas = false
                } else campo.append(ch)
            } else {
                when (ch) {
                    '"' -> aspas = true
                    sep -> { campos.add(campo.toString()); campo.setLength(0) }
                    '\r' -> {}
                    '\n' -> {
                        campos.add(campo.toString()); campo.setLength(0)
                        if (campos.any { it.isNotBlank() }) linhas.add(campos)
                        campos = ArrayList()
                    }
                    else -> campo.append(ch)
                }
            }
            i++
        }
        campos.add(campo.toString())
        if (campos.any { it.isNotBlank() }) linhas.add(campos)
        return linhas.map { l -> l.map { limparCelula(it) } }
    }

    /** Remove o formato ="123" usado para proteger códigos no Excel. */
    private fun limparCelula(v: String): String {
        val t = v.trim()
        if (t.startsWith("=\"") && t.endsWith("\"") && t.length >= 3) return t.substring(2, t.length - 1)
        return t
    }

    // ---------------- XLS (jxl) ----------------

    private fun lerXls(bytes: ByteArray): List<Planilha> {
        val ws = WorkbookSettings()
        ws.setEncoding("Cp1252")
        ws.setGCDisabled(true)
        ws.setSuppressWarnings(true)
        val wb = Workbook.getWorkbook(ByteArrayInputStream(bytes), ws)
        try {
            return wb.sheets.map { sh ->
                val linhas = ArrayList<List<String>>()
                for (r in 0 until sh.rows) {
                    val linha = sh.getRow(r).map { cell ->
                        if (cell.type == CellType.NUMBER || cell.type == CellType.NUMBER_FORMULA) {
                            numeroTexto((cell as NumberCell).value)
                        } else cell.contents?.trim() ?: ""
                    }
                    if (linha.any { it.isNotBlank() }) linhas.add(linha)
                }
                Planilha(sh.name, linhas)
            }
        } finally {
            wb.close()
        }
    }

    private fun numeroTexto(d: Double): String =
        try { BigDecimal.valueOf(d).stripTrailingZeros().toPlainString() } catch (e: Exception) { d.toString() }

    private fun numeroTexto(s: String): String =
        try { BigDecimal(s.trim()).stripTrailingZeros().toPlainString() } catch (e: Exception) { s }

    // ---------------- XLSX / XLSM ----------------

    private fun lerXlsx(bytes: ByteArray): List<Planilha> {
        val arquivos = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                val n = e.name.trimStart('/')
                if (!e.isDirectory && (n.endsWith(".xml") || n.endsWith(".rels"))) {
                    arquivos[n] = zip.readBytes()
                }
                e = zip.nextEntry
            }
        }
        val compartilhadas = arquivos["xl/sharedStrings.xml"]?.let { lerSharedStrings(it) } ?: emptyList()

        // id do relacionamento -> caminho da aba
        val rels = HashMap<String, String>()
        arquivos["xl/_rels/workbook.xml.rels"]?.let { b ->
            percorrer(b) { p ->
                if (p.eventType == XmlPullParser.START_TAG && local(p.name) == "Relationship") {
                    val id = p.getAttributeValue(null, "Id")
                    var alvo = p.getAttributeValue(null, "Target") ?: ""
                    alvo = if (alvo.startsWith("/")) alvo.trimStart('/') else "xl/" + alvo
                    if (id != null) rels[id] = alvo
                }
            }
        }

        val abas = ArrayList<Pair<String, String>>() // nome, caminho
        arquivos["xl/workbook.xml"]?.let { b ->
            percorrer(b) { p ->
                if (p.eventType == XmlPullParser.START_TAG && local(p.name) == "sheet") {
                    val nome = p.getAttributeValue(null, "name") ?: "Planilha"
                    var rid: String? = null
                    for (i in 0 until p.attributeCount) {
                        if (p.getAttributeName(i) == "id" || p.getAttributeName(i).endsWith(":id")) rid = p.getAttributeValue(i)
                    }
                    val caminho = rid?.let { rels[it] }
                    if (caminho != null) abas.add(nome to caminho)
                }
            }
        }
        if (abas.isEmpty()) {
            arquivos.keys.filter { it.startsWith("xl/worksheets/sheet") }.sorted()
                .forEachIndexed { i, k -> abas.add("Planilha ${i + 1}" to k) }
        }

        return abas.mapNotNull { (nome, caminho) ->
            arquivos[caminho]?.let { Planilha(nome, lerAba(it, compartilhadas)) }
        }
    }

    private fun percorrer(bytes: ByteArray, bloco: (XmlPullParser) -> Unit) {
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(ByteArrayInputStream(bytes) as InputStream, null)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            bloco(p)
            ev = p.next()
        }
    }

    private fun local(nome: String?): String = nome?.substringAfter(':') ?: ""

    private fun lerSharedStrings(bytes: ByteArray): List<String> {
        val lista = ArrayList<String>()
        val atual = StringBuilder()
        var dentroT = false
        var dentroFonetica = false
        percorrer(bytes) { p ->
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (local(p.name)) {
                    "si" -> atual.setLength(0)
                    "t" -> dentroT = true
                    "rPh" -> dentroFonetica = true
                }
                XmlPullParser.END_TAG -> when (local(p.name)) {
                    "si" -> lista.add(atual.toString())
                    "t" -> dentroT = false
                    "rPh" -> dentroFonetica = false
                }
                XmlPullParser.TEXT -> if (dentroT && !dentroFonetica) atual.append(p.text)
            }
        }
        return lista
    }

    private fun colunaIndice(ref: String): Int {
        var n = 0
        for (c in ref) {
            if (c in 'A'..'Z') n = n * 26 + (c - 'A' + 1) else if (c in 'a'..'z') n = n * 26 + (c - 'a' + 1) else break
        }
        return n - 1
    }

    private fun lerAba(bytes: ByteArray, compartilhadas: List<String>): List<List<String>> {
        val linhas = ArrayList<List<String>>()
        var linha = HashMap<Int, String>()
        var colAtual = -1
        var proximaCol = 0
        var tipo: String? = null
        val valor = StringBuilder()
        var dentroValor = false
        var temValor = false

        percorrer(bytes) { p ->
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (local(p.name)) {
                    "row" -> { linha = HashMap(); proximaCol = 0 }
                    "c" -> {
                        val r = p.getAttributeValue(null, "r")
                        colAtual = if (r != null) colunaIndice(r) else proximaCol
                        if (colAtual < 0) colAtual = proximaCol
                        tipo = p.getAttributeValue(null, "t")
                        valor.setLength(0); temValor = false
                    }
                    "v", "t" -> { dentroValor = true; temValor = true }
                }
                XmlPullParser.TEXT -> if (dentroValor) valor.append(p.text)
                XmlPullParser.END_TAG -> when (local(p.name)) {
                    "v", "t" -> dentroValor = false
                    "c" -> {
                        if (temValor) {
                            val bruto = valor.toString()
                            val texto = when (tipo) {
                                "s" -> compartilhadas.getOrNull(bruto.trim().toIntOrNull() ?: -1) ?: ""
                                "str", "inlineStr" -> bruto
                                "b" -> if (bruto.trim() == "1") "VERDADEIRO" else "FALSO"
                                "e" -> ""
                                else -> numeroTexto(bruto)
                            }
                            linha[colAtual] = texto.trim()
                        }
                        proximaCol = colAtual + 1
                    }
                    "row" -> {
                        if (linha.values.any { it.isNotBlank() }) {
                            val max = linha.keys.maxOrNull() ?: -1
                            linhas.add((0..max).map { linha[it] ?: "" })
                        }
                    }
                }
            }
        }
        return linhas
    }
}
