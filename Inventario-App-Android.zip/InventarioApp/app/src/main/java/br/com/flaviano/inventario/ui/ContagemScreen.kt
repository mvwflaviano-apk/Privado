package br.com.flaviano.inventario.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import br.com.flaviano.inventario.data.ItemContado
import br.com.flaviano.inventario.data.ProdutoCadastrado
import br.com.flaviano.inventario.data.Repositorio
import br.com.flaviano.inventario.data.ResultadoLeitura
import br.com.flaviano.inventario.util.Feedback
import br.com.flaviano.inventario.util.Formatos
import br.com.flaviano.inventario.util.LeitorIntent
import br.com.flaviano.inventario.util.Preferencias
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private data class Aviso(val texto: String, val erro: Boolean)

@Composable
fun ContagemScreen(sessaoId: Long, nav: NavController) {
    val ctx = LocalContext.current
    val repo = remember { Repositorio.get(ctx) }
    val prefs = remember { Preferencias(ctx) }
    val feedback = remember { Feedback(ctx, prefs) }
    DisposableEffect(Unit) { onDispose { feedback.liberar() } }

    val sessao by remember { repo.sessoes.observar(sessaoId) }.collectAsState(initial = null)
    val itens by remember { repo.itens.observarDaSessao(sessaoId) }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var codigo by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf<Aviso?>(null) }
    var naoLocalizado by remember { mutableStateOf<String?>(null) }
    var tecladoVisivel by remember { mutableStateOf(!prefs.esconderTeclado) }
    var menu by remember { mutableStateOf(false) }
    val foco = remember { FocusRequester() }
    val teclado = LocalSoftwareKeyboardController.current

    fun focarCampo() {
        try { foco.requestFocus() } catch (_: Exception) { }
        if (tecladoVisivel) teclado?.show() else teclado?.hide()
    }

    fun processar(bruto: String) {
        codigo = ""
        val c = Formatos.limparCodigo(bruto)
        if (c.isEmpty()) return
        if (naoLocalizado != null) { feedback.erro(); return } // resolva o diálogo primeiro
        scope.launch {
            when (val r = repo.registrarLeitura(sessaoId, c)) {
                is ResultadoLeitura.Somado -> {
                    feedback.ok()
                    aviso = Aviso("+1  ${r.item.produto.ifBlank { r.item.codigoBarras }}  →  ${Formatos.quantidade(r.item.quantidade)}", false)
                }
                is ResultadoLeitura.Criado -> {
                    feedback.ok()
                    aviso = Aviso("Novo: ${r.item.produto}  →  1", false)
                }
                is ResultadoLeitura.NaoLocalizado -> {
                    feedback.erro()
                    aviso = Aviso("Produto não localizado: ${r.codigo}", true)
                    naoLocalizado = r.codigo
                }
                ResultadoLeitura.CodigoVazio -> {}
            }
        }
    }

    val processarAtual by rememberUpdatedState<(String) -> Unit>({ processar(it) })

    // Leitura por Intent (broadcast do coletor), se configurada
    val acao = remember { prefs.intentAcao }
    val extra = remember { prefs.intentExtra }
    DisposableEffect(acao) {
        if (acao.isBlank()) return@DisposableEffect onDispose { }
        val receptor = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                val v = intent?.let { LeitorIntent.extrair(it, extra) }
                if (!v.isNullOrBlank()) processarAtual(v)
            }
        }
        ContextCompat.registerReceiver(ctx, receptor, IntentFilter(acao), ContextCompat.RECEIVER_EXPORTED)
        onDispose { try { ctx.unregisterReceiver(receptor) } catch (_: Exception) { } }
    }

    LaunchedEffect(naoLocalizado) {
        if (naoLocalizado == null) {
            delay(150)
            focarCampo()
        }
    }

    // Some com o aviso depois de alguns segundos
    LaunchedEffect(aviso) {
        if (aviso != null && aviso?.erro == false) {
            delay(4000)
            aviso = null
        }
    }

    val totalQtd = itens.sumOf { it.quantidade }

    Scaffold(
        topBar = {
            Barra(
                titulo = sessao?.nome ?: "Contagem",
                subtitulo = "${itens.size} itens · ${Formatos.quantidade(totalQtd)} unidades",
                nav = nav,
            ) {
                IconButton(onClick = { nav.navigate("exportar/$sessaoId") }) { Icon(Icons.Filled.Share, "Exportar") }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Mais") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(if (tecladoVisivel) "Esconder teclado" else "Mostrar teclado") },
                            onClick = { menu = false; tecladoVisivel = !tecladoVisivel; focarCampo() },
                        )
                        DropdownMenuItem(text = { Text("Produtos") }, onClick = { menu = false; nav.navigate("produtos") })
                        DropdownMenuItem(text = { Text("Configurações") }, onClick = { menu = false; nav.navigate("config") })
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(12.dp)
            ) {
                OutlinedTextField(
                    value = codigo,
                    onValueChange = { v ->
                        // Coletores costumam terminar a leitura com Enter ou Tab
                        if (v.contains('\n') || v.contains('\r') || v.contains('\t')) processar(v) else codigo = v
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(foco)
                        .onPreviewKeyEvent { e ->
                            if (e.key == Key.Enter || e.key == Key.NumPadEnter || e.key == Key.Tab) {
                                if (e.type == KeyEventType.KeyDown) processar(codigo)
                                true
                            } else false
                        },
                    label = { Text("Código de barras (leia com o coletor)") },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.titleLarge,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { processar(codigo) }),
                    trailingIcon = {
                        IconButton(onClick = { processar(codigo) }) { Icon(Icons.Filled.Check, "Registrar") }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    ),
                )
                aviso?.let { a ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        a.texto,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (a.erro) VermelhoClaro else VerdeClaro, MaterialTheme.shapes.small)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        color = if (a.erro) Vermelho else Verde,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            if (itens.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("Nenhum item contado ainda.\nLeia o primeiro código de barras.")
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(itens, key = { it.id }) { item ->
                        LinhaItem(
                            item,
                            abrir = { nav.navigate("item/${item.id}") },
                            mais = { scope.launch { repo.ajustarQuantidade(item, 1.0); focarCampo() } },
                            menos = { scope.launch { repo.ajustarQuantidade(item, -1.0); focarCampo() } },
                        )
                    }
                }
            }
        }
    }

    naoLocalizado?.let { cod ->
        DialogoNaoLocalizado(
            codigo = cod,
            repo = repo,
            fechar = { naoLocalizado = null },
            cadastrar = { desc, salvar ->
                naoLocalizado = null
                scope.launch {
                    val novo = repo.adicionarItemManual(sessaoId, cod, desc, salvar)
                    aviso = Aviso("Novo: ${novo.produto.ifBlank { cod }}  →  ${Formatos.quantidade(novo.quantidade)}", false)
                }
            },
            vincular = { produto, substituir ->
                naoLocalizado = null
                scope.launch {
                    val novo = repo.vincularCodigo(sessaoId, cod, produto, substituir)
                    aviso = Aviso("Vinculado: ${novo.produto}  →  ${Formatos.quantidade(novo.quantidade)}", false)
                }
            },
        )
    }
}

@Composable
private fun LinhaItem(item: ItemContado, abrir: () -> Unit, mais: () -> Unit, menos: () -> Unit) {
    val semDescricao = item.produto.isBlank()
    Card(
        Modifier.fillMaxWidth().clickable(onClick = abrir),
        colors = CardDefaults.cardColors(
            containerColor = if (semDescricao) VermelhoClaro else MaterialTheme.colorScheme.surfaceVariant
        ),
    ) {
        Row(Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (semDescricao) "Produto não localizado" else item.produto,
                    fontWeight = FontWeight.SemiBold,
                    color = if (semDescricao) Vermelho else MaterialTheme.colorScheme.onSurface,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Text(item.codigoBarras, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "${item.dataContagem} ${item.horarioContagem}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = menos, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(40.dp)) {
                Text("−", fontSize = 24.sp)
            }
            Text(
                Formatos.quantidade(item.quantidade),
                fontSize = 22.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.widthIn(min = 40.dp),
            )
            TextButton(onClick = mais, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(40.dp)) {
                Text("+", fontSize = 24.sp)
            }
        }
    }
}

@Composable
private fun DialogoNaoLocalizado(
    codigo: String,
    repo: Repositorio,
    fechar: () -> Unit,
    cadastrar: (descricao: String, salvarNoCadastro: Boolean) -> Unit,
    vincular: (ProdutoCadastrado, substituir: Boolean) -> Unit,
) {
    var aba by remember { mutableIntStateOf(0) }
    var descricao by remember { mutableStateOf("") }
    var salvarNoCadastro by remember { mutableStateOf(true) }
    var busca by remember { mutableStateOf("") }
    var escolhido by remember { mutableStateOf<ProdutoCadastrado?>(null) }
    var substituir by remember { mutableStateOf(false) }
    val resultados by remember(busca) { repo.produtos.observar(busca.trim()) }.collectAsState(initial = emptyList())

    AlertDialog(
        onDismissRequest = { },
        icon = { Icon(Icons.Filled.Warning, null, tint = Vermelho) },
        title = { Text("Produto não localizado") },
        text = {
            Column {
                Text("O código abaixo não está na lista de produtos:")
                Text(codigo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                TabRow(selectedTabIndex = aba) {
                    Tab(selected = aba == 0, onClick = { aba = 0 }, text = { Text("Cadastrar") })
                    Tab(selected = aba == 1, onClick = { aba = 1 }, text = { Text("Vincular") })
                }
                Spacer(Modifier.height(8.dp))
                if (aba == 0) {
                    OutlinedTextField(
                        value = descricao, onValueChange = { descricao = it },
                        label = { Text("Descrição do produto") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = salvarNoCadastro, onCheckedChange = { salvarNoCadastro = it })
                        Text("Salvar na lista de produtos")
                    }
                } else {
                    OutlinedTextField(
                        value = busca, onValueChange = { busca = it; escolhido = null },
                        label = { Text("Buscar produto cadastrado") },
                        leadingIcon = { Icon(Icons.Filled.Search, null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    LazyColumn(Modifier.heightIn(max = 200.dp)) {
                        items(resultados.take(50), key = { it.id }) { p ->
                            val sel = escolhido?.id == p.id
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .background(if (sel) AzulClaro else MaterialTheme.colorScheme.surface)
                                    .clickable { escolhido = p }
                                    .padding(8.dp)
                            ) {
                                Text(p.produto, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(p.codigoBarras, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = substituir, onCheckedChange = { substituir = it })
                        Text("Substituir o código antigo do produto (senão, o produto fica com os dois códigos)",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            if (aba == 0) {
                TextButton(onClick = { cadastrar(descricao, salvarNoCadastro) }) {
                    Text(if (descricao.isBlank()) "Contar sem descrição" else "Adicionar")
                }
            } else {
                TextButton(enabled = escolhido != null, onClick = { escolhido?.let { vincular(it, substituir) } }) {
                    Text("Vincular e contar")
                }
            }
        },
        dismissButton = { TextButton(onClick = fechar) { Text("Ignorar leitura") } },
    )
}
