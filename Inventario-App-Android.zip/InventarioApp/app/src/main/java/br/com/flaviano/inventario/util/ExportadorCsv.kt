package br.com.flaviano.inventario.util

import br.com.flaviano.inventario.data.ItemContado
import br.com.flaviano.inventario.data.SessaoInventario

/** Gera o CSV da sessão, compatível com o Excel em português (UTF-8 com BOM, separador ";"). */
object ExportadorCsv {

    fun nomeArquivo(sessao: SessaoInventario, quando: Long): String =
        "${Formatos.nomeArquivoSeguro(sessao.nome)}_${Formatos.paraArquivo(quando)}.csv"

    fun gerar(itens: List<ItemContado>, prefs: Preferencias): ByteArray {
        val sep = prefs.separadorCsv.ifEmpty { ";" }
        val sb = StringBuilder()
        sb.append('﻿') // BOM: o Excel reconhece acentos
        sb.append(listOf("Produto", "Código de barras", "Quantidade", "Data da contagem", "Horário da contagem")
            .joinToString(sep) { campo(it, sep) })
        sb.append("\r\n")
        for (i in itens) {
            val codigo = if (prefs.protegerCodigoExcel) "=\"${i.codigoBarras.replace("\"", "")}\"" else i.codigoBarras
            val qtd = if (sep == ",") Formatos.quantidade(i.quantidade).replace(".", "") else Formatos.quantidade(i.quantidade)
            sb.append(
                listOf(
                    campo(i.produto, sep),
                    if (prefs.protegerCodigoExcel) codigo else campo(codigo, sep), // ="789..." sem aspas externas
                    campo(qtd, sep),
                    campo(i.dataContagem, sep),
                    campo(i.horarioContagem, sep),
                ).joinToString(sep)
            )
            sb.append("\r\n")
        }
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    private fun campo(v: String, sep: String): String =
        if (v.contains(sep) || v.contains('"') || v.contains('\n') || v.contains('\r'))
            "\"" + v.replace("\"", "\"\"") + "\""
        else v
}
