package br.com.flaviano.inventario.ui

import android.database.sqlite.SQLiteConstraintException
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import br.com.flaviano.inventario.data.ProdutoCadastrado
import br.com.flaviano.inventario.data.Repositorio
import br.com.flaviano.inventario.util.Formatos
import kotlinx.coroutines.launch

@Composable
fun ProdutosScreen(nav: NavController) {
    val ctx = LocalContext.current
    val repo = remember { Repositorio.get(ctx) }
    val scope = rememberCoroutineScope()
    var busca by remember { mutableStateOf("") }
    val lista by remember(busca) { repo.produtos.observar(busca.trim()) }.collectAsState(initial = emptyList())
    val total by remember { repo.produtos.observarTotal() }.collectAsState(initial = 0)

    var editando by remember { mutableStateOf<ProdutoCadastrado?>(null) }
    var novo by remember { mutableStateOf(false) }
    var apagarTodos by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }

    Scaffold(
        topBar = {
            Barra("Produtos", nav, subtitulo = "$total cadastrados") {
                IconButton(onClick = { nav.navigate("importar") }) { Icon(Icons.Filled.Add, "Importar") }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Mais") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Importar lista (.xls, .xlsm, .csv)") },
                            onClick = { menu = false; nav.navigate("importar") })
                        DropdownMenuItem(text = { Text("Apagar todos os produtos") },
                            onClick = { menu = false; apagarTodos = true })
                    }
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { novo = true },
                icon = { Icon(Icons.Filled.Create, null) },
                text = { Text("Cadastrar") },
            )
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = busca, onValueChange = { busca = it },
                label = { Text("Buscar por descrição ou código") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (busca.isNotEmpty()) IconButton(onClick = { busca = "" }) { Icon(Icons.Filled.Clear, "Limpar") }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(12.dp),
            )
            if (total == 0) {
                Text(
                    "Nenhum produto cadastrado.\n\nUse \"Cadastrar\" para incluir um a um, ou o botão + no topo " +
                        "para importar uma planilha (.xls, .xlsm ou .csv) com código de barras e descrição.",
                    modifier = Modifier.padding(24.dp),
                )
            }
            LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
                items(lista, key = { it.id }) { p ->
                    Column(
                        Modifier.fillMaxWidth().clickable { editando = p }.padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(p.produto, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(p.codigoBarras, style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    if (novo || editando != null) {
        val atual = editando
        DialogoProduto(
            inicial = atual,
            fechar = { novo = false; editando = null },
            excluir = atual?.let { p ->
                {
                    editando = null
                    scope.launch { repo.produtos.excluir(p) }
                    Unit
                }
            },
        ) { codigo, descricao ->
            val cod = Formatos.limparCodigo(codigo)
            scope.launch {
                try {
                    if (atual == null) {
                        val existente = repo.produtos.porCodigo(cod)
                        if (existente != null) {
                            repo.produtos.atualizar(existente.copy(produto = descricao.trim()))
                            snack.showSnackbar("Código já existia: descrição atualizada.")
                        } else {
                            repo.produtos.salvar(ProdutoCadastrado(produto = descricao.trim(), codigoBarras = cod))
                        }
                    } else {
                        repo.produtos.atualizar(atual.copy(produto = descricao.trim(), codigoBarras = cod))
                    }
                    novo = false; editando = null
                } catch (e: SQLiteConstraintException) {
                    snack.showSnackbar("Já existe outro produto com o código $cod.")
                }
            }
        }
    }

    if (apagarTodos) {
        AlertDialog(
            onDismissRequest = { apagarTodos = false },
            title = { Text("Apagar todos os produtos?") },
            text = { Text("A lista de produtos será esvaziada. As contagens já feitas não são afetadas.") },
            confirmButton = {
                TextButton(onClick = { apagarTodos = false; scope.launch { repo.produtos.excluirTodos() } }) {
                    Text("Apagar", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { apagarTodos = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun DialogoProduto(
    inicial: ProdutoCadastrado?,
    fechar: () -> Unit,
    excluir: (() -> Unit)?,
    salvar: (codigo: String, descricao: String) -> Unit,
) {
    var codigo by remember { mutableStateOf(inicial?.codigoBarras ?: "") }
    var descricao by remember { mutableStateOf(inicial?.produto ?: "") }
    AlertDialog(
        onDismissRequest = fechar,
        title = { Text(if (inicial == null) "Cadastrar produto" else "Editar produto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = codigo, onValueChange = { v -> codigo = v.filter { it != '\n' && it != '\r' && it != '\t' } },
                    label = { Text("Código de barras") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = descricao, onValueChange = { descricao = it },
                    label = { Text("Descrição do produto") }, modifier = Modifier.fillMaxWidth(),
                )
                if (excluir != null) {
                    TextButton(onClick = excluir) { Text("Excluir este produto", color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = codigo.isNotBlank() && descricao.isNotBlank(),
                onClick = { salvar(codigo, descricao) },
            ) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = fechar) { Text("Cancelar") } },
    )
}
