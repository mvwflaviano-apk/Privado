package br.com.flaviano.inventario.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import br.com.flaviano.inventario.data.Repositorio
import br.com.flaviano.inventario.util.ExportadorCsv
import br.com.flaviano.inventario.util.Formatos
import br.com.flaviano.inventario.util.Preferencias
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ExportarScreen(sessaoId: Long, nav: NavController) {
    val ctx = LocalContext.current
    val repo = remember { Repositorio.get(ctx) }
    val prefs = remember { Preferencias(ctx) }
    val scope = rememberCoroutineScope()
    val sessao by remember { repo.sessoes.observar(sessaoId) }.collectAsState(initial = null)
    val itens by remember { repo.itens.observarDaSessao(sessaoId) }.collectAsState(initial = emptyList())
    var mensagem by remember { mutableStateOf<String?>(null) }

    /** Gera o CSV e registra a data/hora da exportação. */
    suspend fun gerar(): Pair<String, ByteArray>? {
        val s = repo.sessoes.obter(sessaoId) ?: return null
        val agora = System.currentTimeMillis()
        val lista = repo.itens.listarDaSessao(sessaoId)
        val bytes = ExportadorCsv.gerar(lista, prefs)
        repo.sessoes.marcarExportada(sessaoId, agora)
        return ExportadorCsv.nomeArquivo(s, agora) to bytes
    }

    val salvar = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val r = gerar() ?: return@launch
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(r.second) }
                }
                mensagem = "Arquivo salvo com sucesso."
            } catch (e: Exception) {
                mensagem = "Erro ao salvar: ${e.message}"
            }
        }
    }

    Scaffold(topBar = { Barra("Exportar", nav) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            val s = sessao
            if (s == null) {
                CircularProgressIndicator()
            } else {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(s.nome, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("Criada em ${Formatos.dataHora(s.criadaEm)}")
                        Text("${itens.size} itens · ${Formatos.quantidade(itens.sumOf { it.quantidade })} unidades")
                        Text(
                            s.exportadaEm?.let { "Última exportação: ${Formatos.data(it)} às ${Formatos.hora(it)}" }
                                ?: "Ainda não exportada",
                            color = if (s.exportadaEm != null) Verde else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Text(
                    "O arquivo CSV abre direto no Excel, com as colunas: Produto, Código de barras, Quantidade, " +
                        "Data da contagem e Horário da contagem.",
                    style = MaterialTheme.typography.bodyMedium,
                )

                Button(
                    enabled = itens.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        scope.launch {
                            try {
                                val (nome, bytes) = gerar() ?: return@launch
                                val arquivo = withContext(Dispatchers.IO) {
                                    val pasta = File(ctx.cacheDir, "exports").apply { mkdirs() }
                                    pasta.listFiles()?.forEach { it.delete() }
                                    File(pasta, nome).apply { writeBytes(bytes) }
                                }
                                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", arquivo)
                                val envio = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/csv"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_SUBJECT, "Inventário: ${s.nome}")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                ctx.startActivity(Intent.createChooser(envio, "Enviar inventário"))
                                mensagem = "Exportação registrada."
                            } catch (e: Exception) {
                                mensagem = "Erro ao exportar: ${e.message}"
                            }
                        }
                    },
                ) {
                    Icon(Icons.Filled.Share, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Compartilhar CSV (WhatsApp, e-mail, Drive…)")
                }

                OutlinedButton(
                    enabled = itens.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { salvar.launch(ExportadorCsv.nomeArquivo(s, System.currentTimeMillis())) },
                ) {
                    Icon(Icons.Filled.Done, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Salvar CSV no aparelho")
                }

                if (itens.isEmpty()) Text("Esta contagem ainda não tem itens.", color = MaterialTheme.colorScheme.error)
                mensagem?.let { Text(it, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}
