package br.com.flaviano.inventario.util

import android.content.Intent

/** Extrai o código de barras de um broadcast enviado pelo coletor (modo Intent). */
object LeitorIntent {
    const val ACAO_SUGERIDA = "br.com.flaviano.inventario.SCAN"

    private val chavesComuns = listOf(
        "com.symbol.datawedge.data_string", // Zebra DataWedge
        "barcode_string",                   // Urovo / iData
        "barcodeData",
        "barcode_data",
        "scannerdata",                      // Chainway / alguns genéricos
        "SCAN_BARCODE1",                    // Newland
        "decode_rslt",
        "EXTRA_BARCODE_DECODING_DATA",
        "data",                             // Honeywell (intent)
        "value",
        "barcode",
        "barCode",
        "code",
    )

    @Suppress("DEPRECATION")
    fun extrair(intent: Intent, chaveConfigurada: String): String? {
        val extras = intent.extras ?: return null
        val chaves = if (chaveConfigurada.isNotBlank()) listOf(chaveConfigurada) + chavesComuns else chavesComuns
        for (k in chaves) {
            if (!extras.containsKey(k)) continue
            when (val v = extras.get(k)) {
                is CharSequence -> if (v.isNotBlank()) return v.toString()
                is ByteArray -> {
                    val len = intent.getIntExtra("length", v.size).coerceIn(0, v.size)
                    val s = String(v, 0, len, Charsets.UTF_8)
                    if (s.isNotBlank()) return s
                }
            }
        }
        return null
    }
}
