package br.com.flaviano.inventario.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import br.com.flaviano.inventario.data.ItemContado
import br.com.flaviano.inventario.data.Repositorio
import br.com.flaviano.inventario.util.Formatos
import kotlinx.coroutines.launch

@Composable
fun ItemScreen(itemId: Long, nav: NavController) {
    val ctx = LocalContext.current
    val repo = remember { Repositorio.get(ctx) }
    val scope = rememberCoroutineScope()

    var item by remember { mutableStateOf<ItemContado?>(null) }
    var descricao by remember { mutableStateOf("") }
    var quantidade by remember { mutableStateOf("") }
    var atualizarCadastro by remember { mutableStateOf(true) }
    var confirmarExclusao by remember { mutableStateOf(false) }

    LaunchedEffect(itemId) {
        repo.itens.obter(itemId)?.let {
            item = it
            descricao = it.produto
            quantidade = Formatos.quantidade(it.quantidade).replace(".", "")
        }
    }

    val qtdValida = Formatos.lerQuantidade(quantidade)?.takeIf { it >= 0 }

    Scaffold(topBar = { Barra("Detalhes do item", nav) }) { pad ->
        val atual = item
        if (atual == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Código de barras", style = MaterialTheme.typography.labelMedium)
            Text(atual.codigoBarras, style = MaterialTheme.typography.titleLarge)
            Text(
                "Última contagem: ${atual.dataContagem} às ${atual.horarioContagem}",
                style = MaterialTheme.typography.bodySmall,
            )

            OutlinedTextField(
                value = descricao, onValueChange = { descricao = it },
                label = { Text("Produto (descrição)") },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = atualizarCadastro, onCheckedChange = { atualizarCadastro = it })
                Text("Atualizar também na lista de produtos")
            }

            Text("Quantidade", style = MaterialTheme.typography.labelMedium)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val q = (Formatos.lerQuantidade(quantidade) ?: 0.0) - 1
                    quantidade = Formatos.quantidade(q.coerceAtLeast(0.0)).replace(".", "")
                }) { Text("−", fontSize = 22.sp) }
                OutlinedTextField(
                    value = quantidade, onValueChange = { quantidade = it },
                    singleLine = true,
                    isError = qtdValida == null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    textStyle = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f),
                )
                OutlinedButton(onClick = {
                    val q = (Formatos.lerQuantidade(quantidade) ?: 0.0) + 1
                    quantidade = Formatos.quantidade(q).replace(".", "")
                }) { Text("+", fontSize = 22.sp) }
            }

            Button(
                enabled = qtdValida != null,
                onClick = {
                    scope.launch {
                        repo.salvarItem(atual, descricao, qtdValida ?: atual.quantidade, atualizarCadastro)
                        nav.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Salvar") }

            OutlinedButton(
                onClick = { confirmarExclusao = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            ) { Text("Excluir item da contagem") }
        }
    }

    if (confirmarExclusao) {
        AlertDialog(
            onDismissRequest = { confirmarExclusao = false },
            title = { Text("Excluir item?") },
            text = { Text("O item será removido desta contagem.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmarExclusao = false
                    item?.let { i -> scope.launch { repo.itens.excluir(i); nav.popBackStack() } }
                }) { Text("Excluir", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmarExclusao = false }) { Text("Cancelar") } },
        )
    }
}
