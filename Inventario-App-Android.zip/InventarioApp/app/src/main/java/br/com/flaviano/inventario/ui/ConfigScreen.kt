package br.com.flaviano.inventario.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import br.com.flaviano.inventario.util.LeitorIntent
import br.com.flaviano.inventario.util.Preferencias

@Composable
fun ConfigScreen(nav: NavController) {
    val ctx = LocalContext.current
    val prefs = remember { Preferencias(ctx) }

    var acao by remember { mutableStateOf(prefs.intentAcao) }
    var extra by remember { mutableStateOf(prefs.intentExtra) }
    var esconderTeclado by remember { mutableStateOf(prefs.esconderTeclado) }
    var som by remember { mutableStateOf(prefs.som) }
    var vibrar by remember { mutableStateOf(prefs.vibrar) }
    var proteger by remember { mutableStateOf(prefs.protegerCodigoExcel) }
    var separador by remember { mutableStateOf(prefs.separadorCsv) }

    Scaffold(topBar = { Barra("Configurações", nav) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Titulo("Leitura pelo coletor")
            Text(
                "Modo teclado (padrão): o coletor \"digita\" o código no campo e envia Enter. Funciona na maioria " +
                    "dos aparelhos sem configurar nada.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Interruptor("Esconder o teclado virtual na tela de contagem", esconderTeclado) {
                esconderTeclado = it; prefs.esconderTeclado = it
            }

            Text(
                "Modo Intent (opcional): configure o app de leitura do coletor (ex.: DataWedge da Zebra, " +
                    "Scanner Settings da Honeywell/Urovo/Chainway) para enviar um broadcast com a ação abaixo. " +
                    "Deixe em branco para desativar.",
                style = MaterialTheme.typography.bodyMedium,
            )
            OutlinedTextField(
                value = acao, onValueChange = { acao = it; prefs.intentAcao = it },
                label = { Text("Ação do Intent (broadcast)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            TextButton(onClick = { acao = LeitorIntent.ACAO_SUGERIDA; prefs.intentAcao = acao }) {
                Text("Usar ação sugerida: ${LeitorIntent.ACAO_SUGERIDA}")
            }
            OutlinedTextField(
                value = extra, onValueChange = { extra = it; prefs.intentExtra = it },
                label = { Text("Nome do extra com o código (opcional)") },
                supportingText = { Text("Em branco: o app tenta os nomes mais comuns (Zebra, Honeywell, Urovo, Newland…).") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )

            HorizontalDivider()
            Titulo("Aviso de leitura")
            Interruptor("Bipe", som) { som = it; prefs.som = it }
            Interruptor("Vibrar", vibrar) { vibrar = it; prefs.vibrar = it }

            HorizontalDivider()
            Titulo("Exportação (CSV)")
            Interruptor("Proteger o código de barras para o Excel (evita aparecer como 7,89E+12)", proteger) {
                proteger = it; prefs.protegerCodigoExcel = it
            }
            Text("Separador de colunas", style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = separador == ";", onClick = { separador = ";"; prefs.separadorCsv = ";" })
                Text("Ponto e vírgula ( ; ) — Excel em português")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = separador == ",", onClick = { separador = ","; prefs.separadorCsv = "," })
                Text("Vírgula ( , )")
            }
        }
    }
}

@Composable
private fun Titulo(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun Interruptor(texto: String, valor: Boolean, mudar: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(texto, Modifier.weight(1f))
        Switch(checked = valor, onCheckedChange = mudar)
    }
}
