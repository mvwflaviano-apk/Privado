package br.com.flaviano.inventario.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

/** Som e vibração ao ler um código. */
class Feedback(private val context: Context, private val prefs: Preferencias) {
    private val tom: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
    } catch (e: Exception) { null }

    fun ok() {
        if (prefs.som) tom?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        if (prefs.vibrar) vibrar(60)
    }

    fun erro() {
        if (prefs.som) tom?.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 400)
        if (prefs.vibrar) vibrar(350)
    }

    @Suppress("DEPRECATION")
    private fun vibrar(ms: Long) {
        try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(ms)
            }
        } catch (_: Exception) {
        }
    }

    fun liberar() {
        tom?.release()
    }
}
