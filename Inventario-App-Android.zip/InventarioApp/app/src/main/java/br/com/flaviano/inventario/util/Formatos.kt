package br.com.flaviano.inventario.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatos {
    private val br = Locale("pt", "BR")

    fun data(millis: Long): String = SimpleDateFormat("dd/MM/yyyy", br).format(Date(millis))
    fun hora(millis: Long): String = SimpleDateFormat("HH:mm:ss", br).format(Date(millis))
    fun dataHora(millis: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", br).format(Date(millis))
    fun paraArquivo(millis: Long): String = SimpleDateFormat("yyyyMMdd_HHmmss", br).format(Date(millis))

    /** 3.0 -> "3"; 2.5 -> "2,5" */
    fun quantidade(q: Double): String {
        val df = DecimalFormat("#,##0.###", DecimalFormatSymbols(br))
        return df.format(q)
    }

    /** Aceita "3", "2,5", "2.5", "1.234,5". Retorna null se inválido. */
    fun lerQuantidade(texto: String): Double? {
        var t = texto.trim().replace(" ", "")
        if (t.isEmpty()) return null
        if (t.contains(',')) t = t.replace(".", "").replace(',', '.')
        return t.toDoubleOrNull()
    }

    /** Limpa um código lido: remove espaços, quebras de linha, caracteres de controle e apóstrofo inicial. */
    fun limparCodigo(bruto: String): String =
        bruto.filter { !it.isISOControl() }.trim().removePrefix("'").trim()

    fun nomeArquivoSeguro(nome: String): String =
        nome.replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_").trim('_').take(60).ifEmpty { "inventario" }
}
