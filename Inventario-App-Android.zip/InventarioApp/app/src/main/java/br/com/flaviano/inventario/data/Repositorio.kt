package br.com.flaviano.inventario.data

import android.content.Context
import androidx.room.withTransaction
import br.com.flaviano.inventario.util.Formatos

sealed class ResultadoLeitura {
    data class Somado(val item: ItemContado) : ResultadoLeitura()
    data class Criado(val item: ItemContado) : ResultadoLeitura()
    data class NaoLocalizado(val codigo: String) : ResultadoLeitura()
    data object CodigoVazio : ResultadoLeitura()
}

class Repositorio(context: Context) {
    val db = AppDatabase.get(context)
    val sessoes = db.sessaoDao()
    val itens = db.itemDao()
    val produtos = db.produtoDao()

    suspend fun criarSessao(nome: String): Long =
        sessoes.inserir(SessaoInventario(nome = nome.trim(), criadaEm = System.currentTimeMillis()))

    /**
     * Processa uma leitura do coletor:
     * - código já na sessão -> soma [quantidade] (sem duplicar linha);
     * - código no cadastro de produtos -> cria item com a descrição;
     * - código desconhecido -> NaoLocalizado (a tela pergunta o que fazer).
     */
    suspend fun registrarLeitura(sessaoId: Long, codigoBruto: String, quantidade: Double = 1.0): ResultadoLeitura {
        val codigo = Formatos.limparCodigo(codigoBruto)
        if (codigo.isEmpty()) return ResultadoLeitura.CodigoVazio
        return db.withTransaction {
            val agora = System.currentTimeMillis()
            val existente = itens.buscar(sessaoId, codigo)
            if (existente != null) {
                var atualizado = existente.copy(
                    quantidade = existente.quantidade + quantidade,
                    dataContagem = Formatos.data(agora),
                    horarioContagem = Formatos.hora(agora),
                    atualizadoEm = agora,
                )
                // Se o item foi contado sem descrição e agora o produto existe no cadastro, completa.
                if (atualizado.produto.isBlank()) {
                    produtos.porCodigo(codigo)?.let { atualizado = atualizado.copy(produto = it.produto) }
                }
                itens.atualizar(atualizado)
                ResultadoLeitura.Somado(atualizado)
            } else {
                val produto = produtos.porCodigo(codigo)
                if (produto == null) {
                    ResultadoLeitura.NaoLocalizado(codigo)
                } else {
                    val novo = novoItem(sessaoId, codigo, produto.produto, quantidade, agora)
                    ResultadoLeitura.Criado(novo.copy(id = itens.inserir(novo)))
                }
            }
        }
    }

    /** Cria o item para um código que não estava no cadastro (com ou sem descrição). */
    suspend fun adicionarItemManual(
        sessaoId: Long, codigo: String, descricao: String, salvarNoCadastro: Boolean, quantidade: Double = 1.0,
    ): ItemContado = db.withTransaction {
        val agora = System.currentTimeMillis()
        val desc = descricao.trim()
        if (salvarNoCadastro && desc.isNotEmpty()) {
            val p = produtos.porCodigo(codigo)
            if (p == null) produtos.salvar(ProdutoCadastrado(produto = desc, codigoBarras = codigo))
            else produtos.atualizar(p.copy(produto = desc))
        }
        val existente = itens.buscar(sessaoId, codigo)
        if (existente != null) {
            val at = existente.copy(
                produto = desc.ifEmpty { existente.produto },
                quantidade = existente.quantidade + quantidade,
                dataContagem = Formatos.data(agora), horarioContagem = Formatos.hora(agora), atualizadoEm = agora,
            )
            itens.atualizar(at); at
        } else {
            val novo = novoItem(sessaoId, codigo, desc, quantidade, agora)
            novo.copy(id = itens.inserir(novo))
        }
    }

    /**
     * Corrige o vínculo: associa o código lido a um produto já cadastrado.
     * Se [substituirCodigo] for true, o produto passa a usar o novo código; senão o código é
     * adicionado como mais um código para a mesma descrição.
     */
    suspend fun vincularCodigo(
        sessaoId: Long, codigo: String, produto: ProdutoCadastrado, substituirCodigo: Boolean,
    ): ItemContado = db.withTransaction {
        if (substituirCodigo) {
            produtos.atualizar(produto.copy(codigoBarras = codigo))
        } else {
            produtos.salvar(ProdutoCadastrado(produto = produto.produto, codigoBarras = codigo))
        }
        adicionarItemManual(sessaoId, codigo, produto.produto, salvarNoCadastro = false)
    }

    /** Edição manual do item (descrição e/ou quantidade). */
    suspend fun salvarItem(item: ItemContado, descricao: String, quantidade: Double, atualizarCadastro: Boolean) {
        db.withTransaction {
            val agora = System.currentTimeMillis()
            itens.atualizar(
                item.copy(
                    produto = descricao.trim(),
                    quantidade = quantidade,
                    dataContagem = Formatos.data(agora),
                    horarioContagem = Formatos.hora(agora),
                    atualizadoEm = agora,
                )
            )
            if (atualizarCadastro && descricao.isNotBlank()) {
                val p = produtos.porCodigo(item.codigoBarras)
                if (p == null) produtos.salvar(ProdutoCadastrado(produto = descricao.trim(), codigoBarras = item.codigoBarras))
                else produtos.atualizar(p.copy(produto = descricao.trim()))
            }
        }
    }

    /** Botões +/− da lista. Não deixa a quantidade ficar negativa. */
    suspend fun ajustarQuantidade(item: ItemContado, delta: Double) {
        val agora = System.currentTimeMillis()
        itens.atualizar(
            item.copy(
                quantidade = (item.quantidade + delta).coerceAtLeast(0.0),
                dataContagem = Formatos.data(agora),
                horarioContagem = Formatos.hora(agora),
                atualizadoEm = agora,
            )
        )
    }

    private fun novoItem(sessaoId: Long, codigo: String, descricao: String, qtd: Double, agora: Long) = ItemContado(
        sessaoId = sessaoId,
        produto = descricao,
        codigoBarras = codigo,
        quantidade = qtd,
        dataContagem = Formatos.data(agora),
        horarioContagem = Formatos.hora(agora),
        atualizadoEm = agora,
    )

    companion object {
        @Volatile private var inst: Repositorio? = null
        fun get(context: Context): Repositorio =
            inst ?: synchronized(this) { inst ?: Repositorio(context.applicationContext).also { inst = it } }
    }
}
