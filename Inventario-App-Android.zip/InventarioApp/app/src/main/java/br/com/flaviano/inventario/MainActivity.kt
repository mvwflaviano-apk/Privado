package br.com.flaviano.inventario

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import br.com.flaviano.inventario.ui.ConfigScreen
import br.com.flaviano.inventario.ui.ContagemScreen
import br.com.flaviano.inventario.ui.ExportarScreen
import br.com.flaviano.inventario.ui.ImportarScreen
import br.com.flaviano.inventario.ui.InventarioTema
import br.com.flaviano.inventario.ui.ItemScreen
import br.com.flaviano.inventario.ui.ProdutosScreen
import br.com.flaviano.inventario.ui.SessoesScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InventarioTema {
                val nav = rememberNavController()
                val idArg = listOf(navArgument("id") { type = NavType.LongType })
                NavHost(navController = nav, startDestination = "sessoes") {
                    composable("sessoes") { SessoesScreen(nav) }
                    composable("contagem/{id}", arguments = idArg) {
                        ContagemScreen(it.arguments?.getLong("id") ?: 0L, nav)
                    }
                    composable("item/{id}", arguments = idArg) {
                        ItemScreen(it.arguments?.getLong("id") ?: 0L, nav)
                    }
                    composable("exportar/{id}", arguments = idArg) {
                        ExportarScreen(it.arguments?.getLong("id") ?: 0L, nav)
                    }
                    composable("produtos") { ProdutosScreen(nav) }
                    composable("importar") { ImportarScreen(nav) }
                    composable("config") { ConfigScreen(nav) }
                }
            }
        }
    }
}
