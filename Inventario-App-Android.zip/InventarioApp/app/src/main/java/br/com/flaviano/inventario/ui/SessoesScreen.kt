package br.com.flaviano.inventario.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import br.com.flaviano.inventario.data.Repositorio
import br.com.flaviano.inventario.data.SessaoResumo
import br.com.flaviano.inventario.util.Formatos
import kotlinx.coroutines.launch

@Composable
fun SessoesScreen(nav: NavController) {
    val ctx = LocalContext.current
    val repo = remember { Repositorio.get(ctx) }
    val sessoes by remember { repo.sessoes.observarResumos() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var criando by remember { mutableStateOf(false) }
    var renomeando by remember { mutableStateOf<SessaoResumo?>(null) }
    var excluindo by remember { mutableStateOf<SessaoResumo?>(null) }

    Scaffold(
        topBar = {
            Barra("Inventários") {
                IconButton(onClick = { nav.navigate("produtos") }) { Icon(Icons.Filled.List, "Produtos") }
                IconButton(onClick = { nav.navigate("config") }) { Icon(Icons.Filled.Settings, "Configurações") }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { criando = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nova contagem") },
            )
        },
    ) { pad ->
        if (sessoes.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Nenhuma contagem ainda.\nToque em \"Nova contagem\" para começar.\n\n" +
                        "Dica: cadastre ou importe a lista de produtos no ícone de lista, no topo.",
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(sessoes, key = { it.id }) { s ->
                    CartaoSessao(
                        s,
                        abrir = { nav.navigate("contagem/${s.id}") },
                        exportar = { nav.navigate("exportar/${s.id}") },
                        renomear = { renomeando = s },
                        excluir = { excluindo = s },
                    )
                }
            }
        }
    }

    if (criando) {
        DialogoNome(
            titulo = "Nova contagem",
            inicial = "Contagem — ${Formatos.data(System.currentTimeMillis())}",
            confirmar = "Criar",
            fechar = { criando = false },
        ) { nome ->
            criando = false
            scope.launch {
                val id = repo.criarSessao(nome)
                nav.navigate("contagem/$id")
            }
        }
    }

    renomeando?.let { s ->
        DialogoNome("Renomear contagem", s.nome, "Salvar", fechar = { renomeando = null }) { nome ->
            renomeando = null
            scope.launch {
                repo.sessoes.obter(s.id)?.let { repo.sessoes.atualizar(it.copy(nome = nome.trim())) }
            }
        }
    }

    excluindo?.let { s ->
        AlertDialog(
            onDismissRequest = { excluindo = null },
            title = { Text("Excluir contagem?") },
            text = { Text("\"${s.nome}\" e seus ${s.totalItens} itens serão apagados. Esta ação não pode ser desfeita.") },
            confirmButton = {
                TextButton(onClick = {
                    excluindo = null
                    scope.launch { repo.sessoes.obter(s.id)?.let { repo.sessoes.excluir(it) } }
                }) { Text("Excluir", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { excluindo = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun CartaoSessao(
    s: SessaoResumo,
    abrir: () -> Unit,
    exportar: () -> Unit,
    renomear: () -> Unit,
    excluir: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().clickable(onClick = abrir)) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.nome, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text("Criada em ${Formatos.dataHora(s.criadaEm)}", style = MaterialTheme.typography.bodySmall)
                Text(
                    "${s.totalItens} itens · ${Formatos.quantidade(s.totalQuantidade ?: 0.0)} unidades",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    s.exportadaEm?.let { "Exportada em ${Formatos.dataHora(it)}" } ?: "Ainda não exportada",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (s.exportadaEm != null) Verde else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Opções") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Abrir") }, onClick = { menu = false; abrir() })
                    DropdownMenuItem(text = { Text("Exportar") }, onClick = { menu = false; exportar() })
                    DropdownMenuItem(text = { Text("Renomear") }, onClick = { menu = false; renomear() })
                    DropdownMenuItem(text = { Text("Excluir") }, onClick = { menu = false; excluir() })
                }
            }
        }
    }
}

@Composable
fun DialogoNome(
    titulo: String,
    inicial: String,
    confirmar: String,
    fechar: () -> Unit,
    salvar: (String) -> Unit,
) {
    var nome by remember { mutableStateOf(inicial) }
    AlertDialog(
        onDismissRequest = fechar,
        title = { Text(titulo) },
        text = {
            OutlinedTextField(
                value = nome, onValueChange = { nome = it },
                label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(enabled = nome.isNotBlank(), onClick = { salvar(nome) }) { Text(confirmar) }
        },
        dismissButton = { TextButton(onClick = fechar) { Text("Cancelar") } },
    )
}
