package br.com.flaviano.inventario.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import br.com.flaviano.inventario.data.Repositorio
import br.com.flaviano.inventario.util.Formatos
import br.com.flaviano.inventario.util.LeitorPlanilha
import br.com.flaviano.inventario.util.Planilha
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ImportarScreen(nav: NavController) {
    val ctx = LocalContext.current
    val repo = remember { Repositorio.get(ctx) }
    val scope = rememberCoroutineScope()

    var nomeArquivo by remember { mutableStateOf("") }
    var planilhas by remember { mutableStateOf<List<Planilha>>(emptyList()) }
    var abaIdx by remember { mutableIntStateOf(0) }
    var temCabecalho by remember { mutableStateOf(true) }
    var colCodigo by remember { mutableIntStateOf(-1) }
    var colDescricao by remember { mutableIntStateOf(-1) }
    var substituirTudo by remember { mutableStateOf(false) }
    var carregando by remember { mutableStateOf(false) }
    var erro by remember { mutableStateOf<String?>(null) }
    var resultado by remember { mutableStateOf<String?>(null) }
    var jaAbriuSeletor by rememberSaveable { mutableStateOf(false) }

    val aba = planilhas.getOrNull(abaIdx)

    fun adivinharColunas(p: Planilha?) {
        colCodigo = -1; colDescricao = -1
        if (p == null) return
        val cab = p.linhas.firstOrNull() ?: return
        cab.forEachIndexed { i, nome ->
            val n = nome.lowercase()
            if (colCodigo < 0 && (n.contains("barra") || n.contains("ean") || n.contains("gtin") || n.startsWith("cod") || n.startsWith("cód"))) colCodigo = i
            else if (colDescricao < 0 && (n.contains("desc") || n.contains("produto") || n.contains("nome") || n.contains("item"))) colDescricao = i
        }
        temCabecalho = colCodigo >= 0 || colDescricao >= 0
        if (colCodigo < 0) colCodigo = if (colDescricao == 0 && p.totalColunas > 1) 1 else 0
        if (colDescricao < 0) colDescricao = if (colCodigo == 0 && p.totalColunas > 1) 1 else 0
    }

    val seletor = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        carregando = true; erro = null; resultado = null
        scope.launch {
            try {
                val lidas = withContext(Dispatchers.IO) { LeitorPlanilha.ler(ctx, uri) }
                nomeArquivo = LeitorPlanilha.nomeDoArquivo(ctx, uri)
                planilhas = lidas.filter { it.linhas.isNotEmpty() }
                abaIdx = 0
                if (planilhas.isEmpty()) erro = "A planilha está vazia."
                adivinharColunas(planilhas.firstOrNull())
            } catch (e: Throwable) {
                erro = "Não foi possível ler o arquivo: ${e.message ?: e.javaClass.simpleName}"
                planilhas = emptyList()
            } finally {
                carregando = false
            }
        }
    }

    fun abrirSeletor() = seletor.launch(arrayOf("*/*"))

    LaunchedEffect(Unit) {
        if (!jaAbriuSeletor) { jaAbriuSeletor = true; abrirSeletor() }
    }

    Scaffold(topBar = { Barra("Importar produtos", nav) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Formatos aceitos: .xls, .xlsm, .xlsx e .csv. A planilha precisa ter uma coluna com o código de barras e outra com a descrição.")
            OutlinedButton(onClick = { abrirSeletor() }, modifier = Modifier.fillMaxWidth()) {
                Text(if (nomeArquivo.isEmpty()) "Escolher arquivo" else "Trocar arquivo")
            }
            if (carregando) LinearProgressIndicator(Modifier.fillMaxWidth())
            erro?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            resultado?.let {
                Card(colors = CardDefaults.cardColors(containerColor = VerdeClaro)) {
                    Text(it, Modifier.padding(12.dp), color = Verde, fontWeight = FontWeight.SemiBold)
                }
                Button(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth()) { Text("Concluir") }
            }

            if (aba != null && resultado == null) {
                Text("Arquivo: $nomeArquivo", fontWeight = FontWeight.SemiBold)

                if (planilhas.size > 1) {
                    Seletor(
                        rotulo = "Aba da planilha",
                        opcoes = planilhas.map { it.nome },
                        selecionado = abaIdx,
                    ) { abaIdx = it; adivinharColunas(planilhas[it]) }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = temCabecalho, onCheckedChange = { temCabecalho = it })
                    Text("A primeira linha é o cabeçalho (nomes das colunas)")
                }

                val nomesColunas = (0 until aba.totalColunas).map { i ->
                    val letra = letraColuna(i)
                    val cab = if (temCabecalho) aba.linhas.first().getOrNull(i).orEmpty() else ""
                    if (cab.isNotBlank()) "$letra — $cab" else "Coluna $letra"
                }
                Seletor("Coluna do CÓDIGO DE BARRAS", nomesColunas, colCodigo) { colCodigo = it }
                Seletor("Coluna da DESCRIÇÃO do produto", nomesColunas, colDescricao) { colDescricao = it }

                val validos = remember(aba, temCabecalho, colCodigo, colDescricao) {
                    val dados = if (temCabecalho) aba.linhas.drop(1) else aba.linhas
                    dados.mapNotNull { l ->
                        val c = Formatos.limparCodigo(l.getOrNull(colCodigo).orEmpty())
                        val d = l.getOrNull(colDescricao).orEmpty().trim()
                        if (c.isEmpty()) null else c to d
                    }
                }

                Text("Prévia (primeiras linhas):", style = MaterialTheme.typography.labelLarge)
                Card {
                    Column(Modifier.padding(8.dp).horizontalScroll(rememberScrollState())) {
                        validos.take(6).forEach { (c, d) ->
                            Row {
                                Text(c, Modifier.width(150.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(d, maxLines = 1)
                            }
                        }
                        if (validos.isEmpty()) Text("Nenhuma linha com código nessa coluna.")
                    }
                }
                Text("${validos.size} produtos serão importados.")

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = substituirTudo, onCheckedChange = { substituirTudo = it })
                    Text("Apagar a lista atual antes de importar (senão, adiciona e atualiza pelo código)")
                }

                Button(
                    enabled = validos.isNotEmpty() && !carregando && colCodigo != colDescricao,
                    onClick = {
                        carregando = true
                        scope.launch {
                            try {
                                // Se o mesmo código aparecer mais de uma vez, vale a última linha
                                val unicos = LinkedHashMap<String, String>()
                                validos.forEach { (c, d) -> unicos[c] = d }
                                val n = withContext(Dispatchers.IO) {
                                    repo.produtos.importar(unicos.map { it.key to it.value }, substituirTudo)
                                }
                                resultado = "$n produtos importados com sucesso."
                            } catch (e: Throwable) {
                                erro = "Erro ao importar: ${e.message}"
                            } finally {
                                carregando = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Importar") }
                if (colCodigo == colDescricao) {
                    Text("Escolha colunas diferentes para código e descrição.", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

private fun letraColuna(i: Int): String {
    var n = i + 1
    val sb = StringBuilder()
    while (n > 0) {
        val r = (n - 1) % 26
        sb.insert(0, ('A' + r))
        n = (n - 1) / 26
    }
    return sb.toString()
}

@Composable
private fun Seletor(rotulo: String, opcoes: List<String>, selecionado: Int, aoEscolher: (Int) -> Unit) {
    var aberto by remember { mutableStateOf(false) }
    Column {
        Text(rotulo, style = MaterialTheme.typography.labelLarge)
        Box {
            OutlinedButton(onClick = { aberto = true }, modifier = Modifier.fillMaxWidth()) {
                Text(
                    opcoes.getOrNull(selecionado) ?: "Selecione",
                    modifier = Modifier.weight(1f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Icon(Icons.Filled.ArrowDropDown, null)
            }
            DropdownMenu(expanded = aberto, onDismissRequest = { aberto = false }) {
                opcoes.forEachIndexed { i, o ->
                    DropdownMenuItem(text = { Text(o) }, onClick = { aberto = false; aoEscolher(i) })
                }
            }
        }
    }
}
