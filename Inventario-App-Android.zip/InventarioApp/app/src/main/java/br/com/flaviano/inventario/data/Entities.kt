package br.com.flaviano.inventario.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Sessão de inventário (ex.: "Estoque loja — 09/10/2026"). */
@Entity(tableName = "sessoes")
data class SessaoInventario(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nome: String,
    /** Data/hora de criação em milissegundos. */
    val criadaEm: Long,
    /** Data/hora da última exportação em milissegundos (null = nunca exportada). */
    val exportadaEm: Long? = null,
)

/** Item contado dentro de uma sessão. Um código de barras aparece no máximo uma vez por sessão. */
@Entity(
    tableName = "itens",
    foreignKeys = [
        ForeignKey(
            entity = SessaoInventario::class,
            parentColumns = ["id"],
            childColumns = ["sessaoId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index(value = ["sessaoId", "codigoBarras"], unique = true)],
)
data class ItemContado(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessaoId: Long,
    val produto: String,
    val codigoBarras: String,
    val quantidade: Double,
    /** dd/MM/yyyy */
    val dataContagem: String,
    /** HH:mm:ss — horário da contagem ou da última atualização. */
    val horarioContagem: String,
    /** Usado só para ordenar (último lido no topo). */
    @ColumnInfo(defaultValue = "0") val atualizadoEm: Long = 0,
)

/** Produto do cadastro (manual ou importado). */
@Entity(
    tableName = "produtos",
    indices = [Index(value = ["codigoBarras"], unique = true)],
)
data class ProdutoCadastrado(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val produto: String,
    val codigoBarras: String,
)

/** Sessão com totais, para a lista de inventários. */
data class SessaoResumo(
    val id: Long,
    val nome: String,
    val criadaEm: Long,
    val exportadaEm: Long?,
    val totalItens: Int,
    val totalQuantidade: Double?,
)
